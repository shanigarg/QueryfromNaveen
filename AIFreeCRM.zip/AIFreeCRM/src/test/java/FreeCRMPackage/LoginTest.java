package FreeCRMPackage;

import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Base.BaseClass;
import Pages.HomePage;
import Pages.LoginPage;
import Pages.MainPage;
import Utils.Utility;

public class LoginTest extends BaseClass{

	String sheetpath = System.getProperty("user.dir")+"/src/main/java/TestData/UserData.xlsx";
	String sheetname = "login_credentials";

	
	public LoginTest() throws IOException {
		super();
	}
	
	@Test
	public void openCRMPageTest() throws InterruptedException, IOException{
		String mainpagetitle = MainPage.getMainPageTitle();
		System.out.println(mainpagetitle);
		Thread.sleep(5000);
		Utility.takeScreenshot();
		Assert.assertEquals(mainpagetitle, MainPage.expmainpagetitle);
	}
	
	@Test (dataProvider = "getLoginData")
	public void loginCRMTest(String username, String password, String displayname) throws InterruptedException, IOException{
		MainPage.clickLoginButton();
		timeOut();
		Utility.takeScreenshot();
		String loginpagetitle = LoginPage.getLoginPageTitle();
		System.out.println(loginpagetitle);
		Assert.assertEquals(loginpagetitle, LoginPage.exploginpagetitle);
		Thread.sleep(4000);
		LoginPage.enterUserName(username);
		LoginPage.enterPassword(password);
		LoginPage.clickSignIn();
		timeOut();
		System.out.println(HomePage.getDisplayName());
		System.out.println(displayname);
		Assert.assertEquals(displayname, HomePage.getDisplayName());
		Thread.sleep(4000);
		Utility.takeScreenshot();

	}
	
	@DataProvider 
	public Object[][] getLoginData() throws InvalidFormatException, IOException{
		Object data[][] = Utility.getTestData(sheetpath, sheetname);
		return data;
	}

}
