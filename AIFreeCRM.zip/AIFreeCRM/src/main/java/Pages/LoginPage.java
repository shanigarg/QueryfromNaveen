package Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Base.BaseClass;

public class LoginPage extends BaseClass{
	
	public static String exploginpagetitle = "Cogmento CRM";
	
	@FindBy(xpath = "//input[@name='email']")
	static WebElement enteremail;
	
	@FindBy(xpath = "//input[@name='password']")
	static WebElement enterpassword;
	
	@FindBy(xpath = "//div[@class='ui fluid large blue submit button']")
	static WebElement signinbutton;
	
	public LoginPage(){
		PageFactory.initElements(objdriver, this);
	}
	
	public static String getLoginPageTitle(){
		return objdriver.getTitle();
	}
	
	public static void enterUserName(String username){
		enteremail.sendKeys(username);
	}
	
	public static void enterPassword(String password){
		enterpassword.sendKeys(password);
	}
	
	public static void clickSignIn(){
		signinbutton.click();
	}
}
