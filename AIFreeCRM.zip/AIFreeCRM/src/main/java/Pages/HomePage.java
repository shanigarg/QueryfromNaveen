package Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.BaseClass;

public class HomePage extends BaseClass{
	
	public static String exphomepagetitle = "Cogmento CRM";
	
	@FindBy(xpath = "//span[@class='user-display']")
	static WebElement userdisplay;
	
	public HomePage(){
		PageFactory.initElements(objdriver, this);
	}
	
	public static String getHomePageTitle(){
		return objdriver.getTitle();
	}
	
	public static String getDisplayName(){
		return userdisplay.getText();
	}

}
