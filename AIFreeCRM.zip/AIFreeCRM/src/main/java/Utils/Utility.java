package Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import Base.BaseClass;

public class Utility extends BaseClass{
	
	static Sheet sheet;
	static Workbook workbook;
	
	public static Object[][] getTestData(String sheetpath, String sheetname) throws InvalidFormatException, IOException {
		FileInputStream file = null;
		file = new FileInputStream(sheetpath);
		workbook = WorkbookFactory.create(file);
		sheet = workbook.getSheet(sheetname);
		Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
		for (int i = 0; i < sheet.getLastRowNum(); i++) {
			for (int k = 0; k < sheet.getRow(0).getLastCellNum(); k++) {
				data[i][k] = sheet.getRow(i + 1).getCell(k).toString();
			}
		}
		return data;
	}

	public static void takeScreenshot() throws IOException {
		File sourcedir = ((TakesScreenshot) objdriver).getScreenshotAs(OutputType.FILE);
		String projectdir = System.getProperty("user.dir");
		FileUtils.copyFile(sourcedir, new File(projectdir + "/Screenshots/"+ System.currentTimeMillis()+".png"));
	}
	
	public static String screenshotExtentReport(WebDriver driver, String screenshotname) throws IOException{
		String datename = new SimpleDateFormat("yyyymmddhhmmss").format(new Date());
		TakesScreenshot takescreenshot = (TakesScreenshot) objdriver;
		File screenshotsource = takescreenshot.getScreenshotAs(OutputType.FILE);
		String destination = System.getProperty("user.dir")+"/FailedTestScreenshots/"+screenshotname+datename+".png";
		File screenshotpath = new File(destination);
		FileUtils.copyFile(screenshotsource, screenshotpath);
		return destination;
	}

}
