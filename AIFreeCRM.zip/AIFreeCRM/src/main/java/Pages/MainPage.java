package Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Base.BaseClass;

public class MainPage extends BaseClass{
	
	public static String expmainpagetitle = "Free CRM #1 cloud software for any business large or small";
	
	@FindBy(xpath = "//a[@class='btn btn-primary btn-xs-2 btn-shadow btn-rect btn-icon btn-icon-left']")
	static WebElement loginbutton;
	
	
	public MainPage(){
		PageFactory.initElements(objdriver, this);
	}
	
	public static void clickLoginButton(){
		loginbutton.click();
	}
	
	public static String getMainPageTitle(){
		return objdriver.getTitle();
	}

}
