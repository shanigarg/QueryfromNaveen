package Base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import ExtentReportListener.ExtentReporterNG;
import FreeCRMPackage.LoginTest;
import Pages.HomePage;
import Pages.LoginPage;
import Pages.MainPage;
import Utils.Utility;
import Utils.WebEventListener;

public class BaseClass {
	
	public static WebDriver objdriver;
	public MainPage mainpage;
	public LoginPage loginpage;
	public HomePage homepage;
	public static EventFiringWebDriver eventfiringdriver;
	public static WebEventListener eventlistener;
	public static Properties configprop;
	
	public BaseClass(){
		try{
		configprop = new Properties();
		FileInputStream file = new FileInputStream(System.getProperty("user.dir")+"/src/main/java/ConfigFiles/QAconfig.properties");
		configprop.load(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void timeOut(){
		objdriver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		objdriver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	}
	
	@BeforeMethod
	public void openFreeCRMURL(){
		
		if (configprop.getProperty("browser").equals("chrome")){
			System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Configurations/BrowserDrivers/chromedriver.exe");
			objdriver = new ChromeDriver();
		}
		else if (configprop.getProperty("browser").equals("IE")){
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"/Configurations/BrowserDrivers/IEDriverServer.exe");
			objdriver = new InternetExplorerDriver();
		}

		eventfiringdriver = new EventFiringWebDriver(objdriver);
		eventlistener = new WebEventListener();
		eventfiringdriver.register(eventlistener);
		objdriver=eventfiringdriver;
		objdriver.manage().window().maximize();
		objdriver.manage().deleteAllCookies();
		objdriver.get(configprop.getProperty("url"));
		mainpage = new MainPage();
		loginpage = new LoginPage();
		homepage = new HomePage();
		
	}
	

	@AfterMethod
	public void closeFreeCRMURL(ITestResult result) throws IOException{
		if(result.getStatus()==ITestResult.FAILURE){
			String screenshotpath = Utility.screenshotExtentReport(objdriver, result.getName());
			ExtentReporterNG.test.log(LogStatus.FAIL, ExtentReporterNG.test.addScreenCapture(screenshotpath));
		}
		
		objdriver.quit();
	}
	
	@AfterTest
	public void endReport() throws InterruptedException{
		ExtentReporterNG.extent.endTest(ExtentReporterNG.test);
		ExtentReporterNG.extent.flush();
		ExtentReporterNG.extent.close();
	}
	
}
